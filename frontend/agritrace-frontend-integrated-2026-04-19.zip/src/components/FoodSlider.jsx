import { useState, useEffect, useRef } from "react";
import "../styles/FoodSlider.css";

const slides = [
  {
    label: "Fresh Vegetables",
    items: [
      { emoji: "🥦", bg: "#1a5c38" }, { emoji: "🥕", bg: "#236b44" },
      { emoji: "🌽", bg: "#1d6040" }, { emoji: "🍅", bg: "#205c3c" },
      { emoji: "🥬", bg: "#1a5c38" }, { emoji: "🧅", bg: "#205c3c" },
      { emoji: "🫑", bg: "#1d6040" }, { emoji: "🥒", bg: "#236b44" },
      { emoji: "🍆", bg: "#1a5c38" }, { emoji: "🧄", bg: "#205c3c" },
    ],
  },
  {
    label: "Seafood & Fish",
    items: [
      { emoji: "🐟", bg: "#1a3a5c" }, { emoji: "🦐", bg: "#1e4468" },
      { emoji: "🦞", bg: "#1a3a5c" }, { emoji: "🦀", bg: "#1e4468" },
      { emoji: "🐠", bg: "#1a3a5c" }, { emoji: "🦑", bg: "#1e4468" },
      { emoji: "🐡", bg: "#1a3a5c" }, { emoji: "🦪", bg: "#1e4468" },
      { emoji: "🐙", bg: "#1a3a5c" }, { emoji: "🐟", bg: "#1e4468" },
    ],
  },
  {
    label: "Fresh Fruits",
    items: [
      { emoji: "🍎", bg: "#6b2a12" }, { emoji: "🍊", bg: "#7a3218" },
      { emoji: "🍋", bg: "#6b2a12" }, { emoji: "🍇", bg: "#7a3218" },
      { emoji: "🍓", bg: "#6b2a12" }, { emoji: "🫐", bg: "#7a3218" },
      { emoji: "🍒", bg: "#6b2a12" }, { emoji: "🍑", bg: "#7a3218" },
      { emoji: "🥭", bg: "#6b2a12" }, { emoji: "🍍", bg: "#7a3218" },
    ],
  },
  {
    label: "Grains & Dairy",
    items: [
      { emoji: "🌾", bg: "#5c4a18" }, { emoji: "🥚", bg: "#6b5520" },
      { emoji: "🧀", bg: "#5c4a18" }, { emoji: "🥛", bg: "#6b5520" },
      { emoji: "🍯", bg: "#5c4a18" }, { emoji: "🥜", bg: "#6b5520" },
      { emoji: "🫘", bg: "#5c4a18" }, { emoji: "🌰", bg: "#6b5520" },
      { emoji: "🍞", bg: "#5c4a18" }, { emoji: "🧈", bg: "#6b5520" },
    ],
  },
];

export default function FoodSlider() {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef(null);

  const goTo = (n) => setCurrent(n);

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 3500);
  };

  useEffect(() => {
    startTimer();
    return () => clearInterval(timerRef.current);
  }, []);

  return (
    <div className="food-slider">
      <div
        className="food-slides"
        style={{ transform: `translateX(-${current * 100}%)` }}
        onMouseEnter={() => clearInterval(timerRef.current)}
        onMouseLeave={startTimer}
      >
        {slides.map((slide, si) => (
          <div className="food-slide" key={si}>
            {slide.items.map((item, ii) => (
              <div
                className="food-cell"
                key={ii}
                style={{ backgroundColor: item.bg }}
              >
                {item.emoji}
              </div>
            ))}
            <div className="food-slide-overlay" />
            <span className="food-slide-label">{slide.label}</span>
          </div>
        ))}
      </div>

      <div className="food-dots">
        {slides.map((_, i) => (
          <button
            key={i}
            className={`food-dot ${i === current ? "active" : ""}`}
            onClick={() => goTo(i)}
          />
        ))}
      </div>
    </div>
  );
}
