export default function StatusBanner({ type = "info", message, onClose }) {
  if (!message) {
    return null;
  }

  return (
    <div className={`status-banner status-${type}`} role="status">
      <span>{message}</span>
      {onClose ? (
        <button type="button" className="banner-close" onClick={onClose} aria-label="Close message">
          ×
        </button>
      ) : null}
    </div>
  );
}

