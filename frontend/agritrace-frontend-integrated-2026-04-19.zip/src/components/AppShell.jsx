import { useEffect, useMemo, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useAppData } from "../context/AppDataContext";
import LoadingSpinner from "./LoadingSpinner";
import StatusBanner from "./StatusBanner";
import "../styles/AppShell.css";
import "../styles/AppPages.css";

const NAV_ITEMS = [
  { label: "Dashboard", path: "/dashboard", access: "dashboard" },
  { label: "Products", path: "/products", access: "products" },
  { label: "Batches", path: "/batches", access: "batches" },
  { label: "Logs", path: "/logs", access: "logs" },
  { label: "Live Locations", path: "/locations", access: "locations" },
  { label: "Reports", path: "/reports", access: "reports" },
  { label: "Notifications", path: "/notifications", access: "notifications" },
  { label: "Audit Trail", path: "/audit", access: "audit" },
];

const PAGE_COPY = {
  "/dashboard": {
    title: "Traceability command center",
    subtitle: "A live view of batches, compliance, and supply movement.",
  },
  "/products": {
    title: "Product registry",
    subtitle: "Create and manage the products moving through your network.",
  },
  "/batches": {
    title: "Batch control",
    subtitle: "Track readiness, quality scores, and shipment dates.",
  },
  "/logs": {
    title: "Chain-of-custody logs",
    subtitle: "Capture every operational handoff and status update.",
  },
  "/locations": {
    title: "Live locations",
    subtitle: "Monitor farms, hubs, transit yards, and retail receiving points.",
  },
  "/reports": {
    title: "Reports and analytics",
    subtitle: "Export traceability insights and compliance trends.",
  },
  "/notifications": {
    title: "Notifications",
    subtitle: "Stay on top of alerts generated from the workflow.",
  },
  "/audit": {
    title: "Audit trail",
    subtitle: "Admin visibility into actions taken across the platform.",
  },
};

export default function AppShell({ children }) {
  const { user, logout, can } = useAuth();
  const {
    notifications,
    notice,
    clearNotice,
    pageError,
    isBootstrapping,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isActionLoading,
  } = useAppData();
  const location = useLocation();
  const navigate = useNavigate();
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  const unreadCount = notifications.filter((item) => item.status === "Unread").length;
  const pageCopy = PAGE_COPY[location.pathname] || PAGE_COPY["/dashboard"];
  const visibleItems = NAV_ITEMS.filter((item) => can(item.access));
  const previewNotifications = useMemo(() => notifications.slice(0, 5), [notifications]);

  useEffect(() => {
    setIsNotificationOpen(false);
  }, [location.pathname]);

  async function handleLogout() {
    await logout();
    navigate("/login");
  }

  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="brand-lockup">
          <div className="brand-mark">AT</div>
          <div>
            <p className="brand-title">AgriTrace</p>
            <p className="brand-subtitle">Frontend workspace</p>
          </div>
        </div>

        <nav className="app-nav">
          {visibleItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                isActive ? "nav-link nav-link-active" : "nav-link"
              }
            >
              <span>{item.label}</span>
              {item.path === "/notifications" && unreadCount > 0 ? (
                <strong className="nav-badge">{unreadCount}</strong>
              ) : null}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-card">
          <p className="eyebrow">Signed in role</p>
          <h3>{user?.role}</h3>
          <p>{user?.orgName}</p>
        </div>
      </aside>

      <main className="app-main">
        <header className="topbar">
          <div>
            <p className="eyebrow">Integrated frontend</p>
            <h1>{pageCopy.title}</h1>
            <p className="topbar-copy">{pageCopy.subtitle}</p>
          </div>

          <div className="topbar-actions">
            <div className="notification-bell-wrap">
              <button
                className="secondary-chip notification-bell"
                type="button"
                onClick={() => setIsNotificationOpen((current) => !current)}
              >
                <span aria-hidden="true">🔔</span>
                <span>Alerts {unreadCount > 0 ? `(${unreadCount})` : ""}</span>
              </button>

              {isNotificationOpen ? (
                <div className="notification-panel">
                  <div className="notification-panel-head">
                    <div>
                      <p className="eyebrow">Notifications</p>
                      <h3>Recent activity</h3>
                    </div>
                    {unreadCount > 0 ? (
                      <button
                        className="link-button"
                        type="button"
                        onClick={() => markAllNotificationsAsRead()}
                        disabled={isActionLoading("markAllNotificationsAsRead")}
                      >
                        {isActionLoading("markAllNotificationsAsRead") ? "Saving..." : "Mark all read"}
                      </button>
                    ) : null}
                  </div>

                  <div className="notification-preview-list">
                    {previewNotifications.length ? (
                      previewNotifications.map((item) => (
                        <div className="notification-preview-item" key={item.notificationId}>
                          <div>
                            <strong>{item.message}</strong>
                            <p>{new Date(item.createdAt).toLocaleString("en-IN")}</p>
                          </div>
                          {item.status === "Unread" ? (
                            <button
                              className="secondary-action"
                              type="button"
                              onClick={() => markNotificationAsRead(item.notificationId)}
                              disabled={isActionLoading("markNotificationAsRead")}
                            >
                              Read
                            </button>
                          ) : (
                            <span className="status-chip neutral-chip">Read</span>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="empty-state compact-empty-state">
                        <h4>No notifications yet</h4>
                        <p>New alerts will appear here as activity happens.</p>
                      </div>
                    )}
                  </div>

                  <button
                    className="secondary-chip full-width-chip"
                    type="button"
                    onClick={() => navigate("/notifications")}
                  >
                    Open notifications page
                  </button>
                </div>
              ) : null}
            </div>
            <div className="profile-chip">
              <span>{user?.name}</span>
              <button className="link-button" onClick={handleLogout}>
                Sign out
              </button>
            </div>
          </div>
        </header>

        <div className="page-frame">
          <StatusBanner type={notice?.type} message={notice?.message} onClose={clearNotice} />
          {!notice?.message && pageError ? (
            <StatusBanner type="error" message={pageError} onClose={clearNotice} />
          ) : null}
          {isBootstrapping ? <LoadingSpinner label="Syncing dashboard data..." /> : children}
        </div>
      </main>
    </div>
  );
}
