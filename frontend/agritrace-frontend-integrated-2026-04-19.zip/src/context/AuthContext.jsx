import { createContext, useContext, useEffect, useState } from "react";
import * as authService from "../services/authService";

const AuthContext = createContext(null);

const PERMISSIONS = {
  Farmer: ["dashboard", "products", "batches", "logs", "locations", "notifications"],
  Processor: ["dashboard", "products", "batches", "logs", "locations", "reports", "notifications"],
  Distributor: ["dashboard", "products", "batches", "logs", "locations", "notifications"],
  Retailer: ["dashboard", "products", "batches", "logs", "notifications"],
  Admin: ["dashboard", "products", "batches", "logs", "locations", "reports", "notifications", "audit"],
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [authError, setAuthError] = useState("");
  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const session = authService.getSession();
    setUser(session.user);
    setToken(session.token);
    setInitializing(false);
  }, []);

  async function login(credentials) {
    setLoading(true);
    setAuthError("");

    try {
      const session = await authService.login(credentials);
      setUser(session.user);
      setToken(session.token);
      return session.user;
    } catch (error) {
      const message = authService.getFriendlyAuthError(error, "Unable to sign in.");
      setAuthError(message);
      throw error;
    } finally {
      setLoading(false);
    }
  }

  async function register(payload) {
    setLoading(true);
    setAuthError("");

    try {
      const session = await authService.register(payload);
      setUser(session.user);
      setToken(session.token);
      return session.user;
    } catch (error) {
      const message = authService.getFriendlyAuthError(error, "Unable to create account.");
      setAuthError(message);
      throw error;
    } finally {
      setLoading(false);
    }
  }

  async function logout() {
    setLoading(true);

    try {
      await authService.logout();
    } finally {
      setUser(null);
      setToken(null);
      setLoading(false);
    }
  }

  function clearError() {
    setAuthError("");
  }

  function hasRole(roles) {
    if (!user?.role) {
      return false;
    }

    const expected = Array.isArray(roles) ? roles : [roles];
    return expected.includes(user.role);
  }

  function can(accessKey) {
    if (!user?.role) {
      return false;
    }

    return (PERMISSIONS[user.role] || []).includes(accessKey);
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        initializing,
        authError,
        isAuthenticated: Boolean(user && token),
        login,
        register,
        logout,
        clearError,
        hasRole,
        can,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }

  return context;
}
