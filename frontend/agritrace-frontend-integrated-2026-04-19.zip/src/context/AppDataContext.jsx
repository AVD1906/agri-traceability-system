import { createContext, useContext, useEffect, useState } from "react";
import { useAuth } from "./AuthContext";
import * as batchService from "../services/batchService";
import * as logService from "../services/logService";
import * as notificationService from "../services/notificationService";
import * as productService from "../services/productService";
import {
  createReadableId,
  getCollection,
  saveCollection,
  seedStorage,
} from "../services/storageService";

const AppDataContext = createContext(null);

export function AppDataProvider({ children }) {
  const { user, isAuthenticated } = useAuth();
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);
  const [logs, setLogs] = useState([]);
  const [locations, setLocations] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [auditEntries, setAuditEntries] = useState([]);
  const [isBootstrapping, setIsBootstrapping] = useState(false);
  const [pageError, setPageError] = useState("");
  const [notice, setNotice] = useState(null);
  const [activeAction, setActiveAction] = useState("");

  async function refreshData() {
    if (!isAuthenticated || !user?.userId) {
      setProducts([]);
      setBatches([]);
      setLogs([]);
      setLocations([]);
      setNotifications([]);
      setAuditEntries([]);
      return;
    }

    setIsBootstrapping(true);
    setPageError("");

    try {
      seedStorage();

      const [productItems, batchItems, logItems, notificationItems] = await Promise.all([
        productService.listProducts(),
        batchService.listBatches(),
        logService.listLogs(),
        notificationService.listNotifications(user.userId),
      ]);

      setProducts(productItems);
      setBatches(batchItems);
      setLogs(logItems);
      setNotifications(notificationItems);
      setLocations(getCollection("locations"));
      setAuditEntries(getCollection("audit"));
    } catch (error) {
      setPageError(error?.response?.data?.message || error?.message || "Unable to load data.");
    } finally {
      setIsBootstrapping(false);
    }
  }

  useEffect(() => {
    refreshData();
  }, [isAuthenticated, user?.userId]);

  function addAudit(action, moduleName, actorName = user?.name || "System") {
    const nextAudit = {
      auditId: createReadableId("AUD"),
      actorName,
      action,
      module: moduleName,
      timestamp: new Date().toISOString(),
    };

    const updated = [nextAudit, ...getCollection("audit")];
    saveCollection("audit", updated);
    setAuditEntries(updated);
  }

  async function addNotification(message, userId = user?.userId) {
    const created = await notificationService.createNotification(message, userId);

    if (!created) {
      return null;
    }

    if (userId === user?.userId) {
      setNotifications((current) => [created, ...current]);
    }

    return created;
  }

  function showNotice(type, message) {
    setNotice({ type, message });
  }

  function clearNotice() {
    setNotice(null);
    setPageError("");
  }

  async function runAction(actionName, callback, successMessage) {
    setActiveAction(actionName);
    setPageError("");
    clearNotice();

    try {
      const result = await callback();

      if (successMessage) {
        showNotice("success", successMessage);
      }

      return result;
    } catch (error) {
      const message = error?.response?.data?.message || error?.message || "Something went wrong.";
      setPageError(message);
      showNotice("error", message);
      throw error;
    } finally {
      setActiveAction("");
    }
  }

  async function createProduct(payload) {
    return runAction("createProduct", async () => {
      const created = await productService.createProduct(payload, user);
      setProducts((current) => [created, ...current]);
      await addNotification(`New product ${created.productName} was added.`);
      addAudit(`Created product ${created.productId}`, "Products");
      return created;
    }, "Product saved successfully.");
  }

  async function createBatch(payload) {
    return runAction("createBatch", async () => {
      const created = await batchService.createBatch(payload, products);
      setBatches((current) => [created, ...current]);
      await addNotification(`Batch ${created.batchId} was created for ${created.productName}.`);
      addAudit(`Created batch ${created.batchId}`, "Batches");
      return created;
    }, "Batch created successfully.");
  }

  async function createLocation(payload) {
    return runAction("createLocation", async () => {
      const nextLocation = {
        locationId: createReadableId("LOC"),
        name: payload.name,
        type: payload.type,
        city: payload.city,
        state: payload.state,
        status: payload.status,
        temperature: payload.temperature || "18 C",
        lastPingMinutes: 1,
        x: Math.floor(Math.random() * 70) + 10,
        y: Math.floor(Math.random() * 60) + 12,
      };

      const updated = [nextLocation, ...getCollection("locations")];
      saveCollection("locations", updated);
      setLocations(updated);
      await addNotification(`Location ${nextLocation.name} is now visible on live tracking.`);
      addAudit(`Added live location ${nextLocation.locationId}`, "Locations");
      return nextLocation;
    }, "Live location added successfully.");
  }

  async function createLog(payload) {
    return runAction("createLog", async () => {
      const created = await logService.createLog(payload, {
        batches,
        locations,
        user,
      });

      setLogs((current) => [created, ...current]);

      const updatedBatch =
        (await batchService.updateBatchStatus(payload.batchId, payload.batchStatus)) || null;

      if (updatedBatch) {
        setBatches((current) =>
          current.map((item) => (item.batchId === payload.batchId ? updatedBatch : item))
        );
      }

      await addNotification(
        `Trace log added for ${created.productName || "selected batch"} at ${created.locationName}.`
      );
      addAudit(`Logged ${payload.stage} for ${payload.batchId}`, "Logs");
      return created;
    }, "Trace log saved successfully.");
  }

  async function markNotificationAsRead(notificationId) {
    return runAction("markNotificationAsRead", async () => {
      await notificationService.markNotificationAsRead(notificationId);
      setNotifications((current) =>
        current.map((item) =>
          item.notificationId === notificationId ? { ...item, status: "Read" } : item
        )
      );
    });
  }

  async function markAllNotificationsAsRead() {
    return runAction("markAllNotificationsAsRead", async () => {
      await notificationService.markAllNotificationsAsRead(user?.userId);
      setNotifications((current) => current.map((item) => ({ ...item, status: "Read" })));
    }, "All notifications marked as read.");
  }

  function isActionLoading(actionName) {
    return activeAction === actionName;
  }

  return (
    <AppDataContext.Provider
      value={{
        products,
        batches,
        logs,
        locations,
        notifications,
        auditEntries,
        isBootstrapping,
        pageError,
        notice,
        activeAction,
        refreshData,
        clearNotice,
        createProduct,
        createBatch,
        createLocation,
        createLog,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        isActionLoading,
      }}
    >
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const context = useContext(AppDataContext);

  if (!context) {
    throw new Error("useAppData must be used inside AppDataProvider");
  }

  return context;
}
