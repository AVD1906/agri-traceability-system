import { useState } from "react";
import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Logs() {
  const { batches, logs, locations, createLog, isActionLoading } = useAppData();
  const [form, setForm] = useState({
    batchId: "",
    stage: "Harvested",
    locationId: "",
    status: "Completed",
    batchStatus: "In Transit",
  });

  function handleSubmit(event) {
    event.preventDefault();

    if (!form.batchId || !form.locationId) {
      return;
    }

    createLog(form).then(() => {
      setForm({
        batchId: "",
        stage: "Harvested",
        locationId: "",
        status: "Completed",
        batchStatus: "In Transit",
      });
    }).catch(() => {});
  }

  return (
    <div className="content-stack">
      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Add trace event</p>
              <h3>Record a chain-of-custody update</h3>
            </div>
          </div>

          <form className="form-stack" onSubmit={handleSubmit}>
            <div className="form-grid">
              <label className="form-span-2">
                Batch
                <select
                  value={form.batchId}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, batchId: event.target.value }))
                  }
                >
                  <option value="">Select a batch</option>
                  {batches.map((item) => (
                    <option key={item.batchId} value={item.batchId}>
                      {item.batchId} - {item.productName}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Stage
                <select
                  value={form.stage}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, stage: event.target.value }))
                  }
                >
                  <option>Harvested</option>
                  <option>Quality Check</option>
                  <option>Dispatched</option>
                  <option>Received</option>
                  <option>Delivered</option>
                </select>
              </label>
              <label>
                Status
                <select
                  value={form.status}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, status: event.target.value }))
                  }
                >
                  <option>Completed</option>
                  <option>Pending Review</option>
                </select>
              </label>
              <label>
                Location
                <select
                  value={form.locationId}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, locationId: event.target.value }))
                  }
                >
                  <option value="">Select a location</option>
                  {locations.map((item) => (
                    <option key={item.locationId} value={item.locationId}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Batch status after log
                <select
                  value={form.batchStatus}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, batchStatus: event.target.value }))
                  }
                >
                  <option>In Transit</option>
                  <option>Ready for Dispatch</option>
                  <option>Delivered</option>
                  <option>Delayed</option>
                </select>
              </label>
            </div>
            <button className="primary-action" type="submit" disabled={isActionLoading("createLog")}>
              {isActionLoading("createLog") ? "Saving..." : "Save log entry"}
            </button>
          </form>
        </article>

        <article className="panel-card accent-card">
          <p className="eyebrow">Connected workflow</p>
          <h3>Logs update batches and notifications</h3>
          <p className="support-copy">
            Every new log entry updates the related batch status and creates a notification
            for the signed-in user, which keeps the whole frontend feeling connected.
          </p>
        </article>
      </section>

      <section className="panel-card">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Log timeline</p>
            <h3>Recent chain events</h3>
          </div>
        </div>

        <div className="timeline-list">
          {[...logs]
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .map((item) => (
              <div className="timeline-item" key={item.logId}>
                <div className="timeline-dot" />
                <div>
                  <strong>{item.stage}</strong>
                  <p>
                    {item.batchId} at {item.locationName}
                  </p>
                </div>
                <time>{formatDate(item.timestamp)}</time>
              </div>
            ))}
        </div>
      </section>
    </div>
  );
}
