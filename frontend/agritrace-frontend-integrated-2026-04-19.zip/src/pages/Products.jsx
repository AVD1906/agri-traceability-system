import { useState } from "react";
import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export default function Products() {
  const { products, createProduct, isActionLoading } = useAppData();
  const [form, setForm] = useState({
    productName: "",
    category: "Vegetables",
    origin: "",
    notes: "",
  });

  function handleSubmit(event) {
    event.preventDefault();

    if (!form.productName.trim() || !form.origin.trim()) {
      return;
    }

    createProduct(form).then(() => {
      setForm({
        productName: "",
        category: "Vegetables",
        origin: "",
        notes: "",
      });
    }).catch(() => {});
  }

  return (
    <div className="content-stack">
      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Add product</p>
              <h3>Create a new registry entry</h3>
            </div>
          </div>

          <form className="form-stack" onSubmit={handleSubmit}>
            <div className="form-grid">
              <label>
                Product name
                <input
                  value={form.productName}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, productName: event.target.value }))
                  }
                  placeholder="Organic Spinach"
                />
              </label>
              <label>
                Category
                <select
                  value={form.category}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, category: event.target.value }))
                  }
                >
                  <option>Vegetables</option>
                  <option>Fruits</option>
                  <option>Dairy</option>
                  <option>Grains</option>
                  <option>Seafood</option>
                </select>
              </label>
              <label className="form-span-2">
                Origin
                <input
                  value={form.origin}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, origin: event.target.value }))
                  }
                  placeholder="Bengaluru Rural, Karnataka"
                />
              </label>
              <label className="form-span-2">
                Notes
                <textarea
                  value={form.notes}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, notes: event.target.value }))
                  }
                  placeholder="Packaging, treatment, or sourcing notes"
                />
              </label>
            </div>
            <button className="primary-action" type="submit" disabled={isActionLoading("createProduct")}>
              {isActionLoading("createProduct") ? "Saving..." : "Save product"}
            </button>
          </form>
        </article>

        <article className="panel-card accent-card">
          <p className="eyebrow">Registry snapshot</p>
          <h3>{products.length} products available</h3>
          <p className="support-copy">
            The API service layer is ready, and if no backend URL is configured the same UI
            continues to work in demo mode.
          </p>
          <div className="stack-list">
            {products.slice(0, 4).map((item) => (
              <div className="soft-row" key={item.productId}>
                <strong>{item.productName}</strong>
                <span>{item.category}</span>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="panel-card">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Registry list</p>
            <h3>All products</h3>
          </div>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Product</th>
                <th>Category</th>
                <th>Origin</th>
                <th>Owner</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {products.map((item) => (
                <tr key={item.productId}>
                  <td>{item.productId}</td>
                  <td>{item.productName}</td>
                  <td>{item.category}</td>
                  <td>{item.origin}</td>
                  <td>{item.ownerName}</td>
                  <td>{formatDate(item.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
