import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import FoodSlider from "../components/FoodSlider";
import { useAuth } from "../context/AuthContext";
import "../styles/Register.css";

const ROLES = ["Farmer", "Processor", "Distributor", "Retailer"];
const STATES = [
  "Karnataka",
  "Maharashtra",
  "Tamil Nadu",
  "Andhra Pradesh",
  "Kerala",
  "Punjab",
  "Gujarat",
  "Uttar Pradesh",
  "Other",
];

function getPasswordStrength(password) {
  let score = 0;

  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^a-zA-Z0-9]/.test(password)) score += 1;

  const labels = ["Too short", "Weak", "Fair", "Strong", "Very strong"];
  const colors = ["#e24b4a", "#ef9f27", "#ef9f27", "#1d9e75", "#1d9e75"];
  const widths = [20, 40, 60, 80, 100];
  const index = Math.min(score, 4);

  return { label: labels[index], color: colors[index], width: widths[index] };
}

export default function Register() {
  const navigate = useNavigate();
  const { register, authError, loading, clearError } = useAuth();

  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("");
  const [orgName, setOrgName] = useState("");
  const [phone, setPhone] = useState("");
  const [region, setRegion] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});

  const strength = password ? getPasswordStrength(password) : null;

  function validateStep1() {
    const nextErrors = {};

    if (!firstName.trim()) nextErrors.firstName = "First name is required.";
    if (!email || !email.includes("@")) nextErrors.email = "Enter a valid email address.";
    if (!password || password.length < 8) nextErrors.password = "Minimum 8 characters required.";
    if (password !== confirmPassword) nextErrors.confirmPassword = "Passwords do not match.";

    return nextErrors;
  }

  function validateStep2() {
    const nextErrors = {};

    if (!role) nextErrors.role = "Please select your role.";
    if (!orgName.trim()) nextErrors.orgName = "Organisation name is required.";

    return nextErrors;
  }

  function goNext(validator, nextStep) {
    const nextErrors = validator();

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    clearError();
    setErrors({});
    setStep(nextStep);
  }

  function handleSubmit() {
    if (!agreed) {
      setErrors({ terms: "Please accept the terms to continue." });
      return;
    }

    clearError();

    register({
      firstName,
      lastName,
      email,
      password,
      role,
      orgName,
      phone,
      region,
    })
      .then(() => navigate("/dashboard"))
      .catch(() => {});
  }

  function StepIndicator() {
    return (
      <div className="step-indicator">
        {[1, 2, 3].map((item) => (
          <div key={item} className="step-indicator-item">
            <div className={`step-circle ${item < step ? "done" : item === step ? "active" : "todo"}`}>
              {item < step ? "✓" : item}
            </div>
            <span className="step-label">
              {item === 1 ? "Details" : item === 2 ? "Role" : "Confirm"}
            </span>
            {item < 3 ? <div className={`step-line ${item < step ? "done" : ""}`} /> : null}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="register-page">
      <FoodSlider />

      <div className="register-content">
        <div className="register-left">
          <div className="reg-logo">
            <div className="reg-logo-icon">🌱</div>
            <span className="reg-logo-name">AgriTrace</span>
          </div>
          <h1 className="reg-tagline">Join the transparent food supply chain.</h1>
          <p className="reg-subtext">
            Create your account and start tracking produce from farm to consumer
            in minutes.
          </p>
          <div className="reg-steps">
            {[
              { number: 1, title: "Your details", sub: "Name, email and password" },
              { number: 2, title: "Your role", sub: "Farmer, processor, distributor or retailer" },
              { number: 3, title: "Confirm & go", sub: "Review and create your account" },
            ].map((item) => (
              <div className="reg-step" key={item.number}>
                <div
                  className={`reg-step-num ${
                    step > item.number ? "done" : step === item.number ? "active" : ""
                  }`}
                >
                  {step > item.number ? "✓" : item.number}
                </div>
                <div>
                  <strong>{item.title}</strong>
                  <p>{item.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="register-right">
          <div className="register-card">
            <h2 className="card-title">Create account</h2>
            <p className="card-sub">Step {step} of 3</p>

            <StepIndicator />

            {step === 1 ? (
              <div>
                <div className="row-2">
                  <div className="form-field">
                    <label>First name</label>
                    <input
                      type="text"
                      placeholder="Riya"
                      value={firstName}
                      onChange={(event) => {
                        setFirstName(event.target.value);
                        setErrors((current) => ({ ...current, firstName: "" }));
                      }}
                      className={errors.firstName ? "input-error" : ""}
                    />
                    {errors.firstName ? <span className="err-msg">{errors.firstName}</span> : null}
                  </div>
                  <div className="form-field">
                    <label>Last name</label>
                    <input
                      type="text"
                      placeholder="Sharma"
                      value={lastName}
                      onChange={(event) => setLastName(event.target.value)}
                    />
                  </div>
                </div>

                <div className="form-field">
                  <label>Email address</label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => {
                      setEmail(event.target.value);
                      setErrors((current) => ({ ...current, email: "" }));
                    }}
                    className={errors.email ? "input-error" : ""}
                  />
                  {errors.email ? <span className="err-msg">{errors.email}</span> : null}
                </div>

                <div className="form-field">
                  <label>Password</label>
                  <input
                    type="password"
                    placeholder="Min. 8 characters"
                    value={password}
                    onChange={(event) => {
                      setPassword(event.target.value);
                      setErrors((current) => ({ ...current, password: "" }));
                    }}
                    className={errors.password ? "input-error" : ""}
                  />
                  {password ? (
                    <>
                      <div className="strength-bar">
                        <div
                          className="strength-fill"
                          style={{ width: `${strength.width}%`, background: strength.color }}
                        />
                      </div>
                      <span className="strength-label" style={{ color: strength.color }}>
                        {strength.label}
                      </span>
                    </>
                  ) : null}
                  {errors.password ? <span className="err-msg">{errors.password}</span> : null}
                </div>

                <div className="form-field">
                  <label>Confirm password</label>
                  <input
                    type="password"
                    placeholder="Repeat password"
                    value={confirmPassword}
                    onChange={(event) => {
                      setConfirmPassword(event.target.value);
                      setErrors((current) => ({ ...current, confirmPassword: "" }));
                    }}
                    className={errors.confirmPassword ? "input-error" : ""}
                  />
                  {errors.confirmPassword ? (
                    <span className="err-msg">{errors.confirmPassword}</span>
                  ) : null}
                </div>

                <button className="btn-primary" type="button" onClick={() => goNext(validateStep1, 2)}>
                  Continue →
                </button>
              </div>
            ) : null}

            {step === 2 ? (
              <div>
                <div className="form-field">
                  <label>I am a</label>
                  <select
                    value={role}
                    onChange={(event) => {
                      setRole(event.target.value);
                      setErrors((current) => ({ ...current, role: "" }));
                    }}
                    className={errors.role ? "input-error" : ""}
                  >
                    <option value="">Select your role</option>
                    {ROLES.map((entry) => (
                      <option key={entry}>{entry}</option>
                    ))}
                  </select>
                  {errors.role ? <span className="err-msg">{errors.role}</span> : null}
                </div>

                <div className="form-field">
                  <label>Organisation / Farm name</label>
                  <input
                    type="text"
                    placeholder="e.g. Green Valley Farms"
                    value={orgName}
                    onChange={(event) => {
                      setOrgName(event.target.value);
                      setErrors((current) => ({ ...current, orgName: "" }));
                    }}
                    className={errors.orgName ? "input-error" : ""}
                  />
                  {errors.orgName ? <span className="err-msg">{errors.orgName}</span> : null}
                </div>

                <div className="form-field">
                  <label>Phone number</label>
                  <input
                    type="tel"
                    placeholder="+91 99999 00000"
                    value={phone}
                    onChange={(event) => setPhone(event.target.value)}
                  />
                </div>

                <div className="form-field">
                  <label>State / Region</label>
                  <select value={region} onChange={(event) => setRegion(event.target.value)}>
                    <option value="">Select state</option>
                    {STATES.map((entry) => (
                      <option key={entry}>{entry}</option>
                    ))}
                  </select>
                </div>

                <div className="btn-row">
                  <button className="btn-secondary" type="button" onClick={() => setStep(1)}>
                    ← Back
                  </button>
                  <button className="btn-primary" type="button" onClick={() => goNext(validateStep2, 3)}>
                    Continue →
                  </button>
                </div>
              </div>
            ) : null}

            {step === 3 ? (
              <div>
                <div className="review-box">
                  <p className="review-heading">Review your details</p>
                  <table className="review-table">
                    <tbody>
                      <tr>
                        <td>Name</td>
                        <td><strong>{`${firstName} ${lastName}`.trim()}</strong></td>
                      </tr>
                      <tr>
                        <td>Email</td>
                        <td>{email}</td>
                      </tr>
                      <tr>
                        <td>Role</td>
                        <td><span className="role-badge">{role}</span></td>
                      </tr>
                      <tr>
                        <td>Organisation</td>
                        <td>{orgName}</td>
                      </tr>
                      <tr>
                        <td>Region</td>
                        <td>{region || "Not specified"}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {authError ? <p className="auth-banner">{authError}</p> : null}

                <label className="terms-row">
                  <input
                    type="checkbox"
                    checked={agreed}
                    onChange={(event) => {
                      setAgreed(event.target.checked);
                      setErrors((current) => ({ ...current, terms: "" }));
                    }}
                  />
                  <span>
                    I agree to the <a href="#">Terms of Service</a> and{" "}
                    <a href="#">Privacy Policy</a> of AgriTrace.
                  </span>
                </label>
                {errors.terms ? <span className="err-msg">{errors.terms}</span> : null}

                <div className="btn-row">
                  <button className="btn-secondary" type="button" onClick={() => setStep(2)}>
                    ← Back
                  </button>
                  <button className="btn-primary" type="button" onClick={handleSubmit} disabled={loading}>
                    {loading ? "Creating..." : "Create account"}
                  </button>
                </div>
              </div>
            ) : null}

            <p className="bottom-link">
              Already have an account? <Link to="/login">Sign in →</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
