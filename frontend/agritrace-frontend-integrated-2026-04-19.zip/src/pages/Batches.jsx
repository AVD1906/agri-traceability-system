import { useState } from "react";
import { useAppData } from "../context/AppDataContext";

export default function Batches() {
  const { products, batches, createBatch, isActionLoading } = useAppData();
  const [form, setForm] = useState({
    productId: "",
    quantity: "",
    harvestDate: "",
    eta: "",
    status: "Ready for Dispatch",
    qualityScore: 95,
    certificateId: "",
  });

  function handleSubmit(event) {
    event.preventDefault();

    if (!form.productId || !form.quantity || !form.harvestDate) {
      return;
    }

    createBatch(form).then(() => {
      setForm({
        productId: "",
        quantity: "",
        harvestDate: "",
        eta: "",
        status: "Ready for Dispatch",
        qualityScore: 95,
        certificateId: "",
      });
    }).catch(() => {});
  }

  return (
    <div className="content-stack">
      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">New batch</p>
              <h3>Register batch details</h3>
            </div>
          </div>

          <form className="form-stack" onSubmit={handleSubmit}>
            <div className="form-grid">
              <label className="form-span-2">
                Product
                <select
                  value={form.productId}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, productId: event.target.value }))
                  }
                >
                  <option value="">Select a product</option>
                  {products.map((item) => (
                    <option key={item.productId} value={item.productId}>
                      {item.productName}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Quantity
                <input
                  value={form.quantity}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, quantity: event.target.value }))
                  }
                  placeholder="650 kg"
                />
              </label>
              <label>
                Harvest date
                <input
                  type="date"
                  value={form.harvestDate}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, harvestDate: event.target.value }))
                  }
                />
              </label>
              <label>
                ETA
                <input
                  type="date"
                  value={form.eta}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, eta: event.target.value }))
                  }
                />
              </label>
              <label>
                Status
                <select
                  value={form.status}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, status: event.target.value }))
                  }
                >
                  <option>Ready for Dispatch</option>
                  <option>In Transit</option>
                  <option>Delivered</option>
                  <option>Delayed</option>
                </select>
              </label>
              <label>
                Quality score
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={form.qualityScore}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, qualityScore: Number(event.target.value) }))
                  }
                />
              </label>
              <label>
                Certificate
                <input
                  value={form.certificateId}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, certificateId: event.target.value }))
                  }
                  placeholder="Auto-generated if blank"
                />
              </label>
            </div>
            <button className="primary-action" type="submit" disabled={isActionLoading("createBatch")}>
              {isActionLoading("createBatch") ? "Creating..." : "Create batch"}
            </button>
          </form>
        </article>

        <article className="panel-card accent-card">
          <p className="eyebrow">Operational note</p>
          <h3>Batch quality is front and center</h3>
          <p className="support-copy">
            Each batch carries quantity, harvest date, ETA, certificate, and quality
            score so the Reports and Logs pages stay connected.
          </p>
        </article>
      </section>

      <section className="card-grid">
        {batches.map((item) => (
          <article className="batch-card" key={item.batchId}>
            <div className="card-row">
              <div>
                <p className="eyebrow">Batch</p>
                <h3>{item.batchId}</h3>
              </div>
              <span className="status-chip">{item.status}</span>
            </div>
            <strong>{item.productName}</strong>
            <p className="support-copy">{item.quantity}</p>
            <div className="detail-grid">
              <div>
                <span>Harvest</span>
                <strong>{item.harvestDate}</strong>
              </div>
              <div>
                <span>ETA</span>
                <strong>{item.eta || "Pending"}</strong>
              </div>
              <div>
                <span>Quality</span>
                <strong>{item.qualityScore}/100</strong>
              </div>
              <div>
                <span>Certificate</span>
                <strong>{item.certificateId}</strong>
              </div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
