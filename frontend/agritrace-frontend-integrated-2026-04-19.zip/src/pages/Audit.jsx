import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Audit() {
  const { auditEntries } = useAppData();

  return (
    <div className="content-stack">
      <section className="panel-card">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Admin only</p>
            <h3>Audit trail</h3>
          </div>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Audit ID</th>
                <th>Actor</th>
                <th>Module</th>
                <th>Action</th>
                <th>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {auditEntries.map((item) => (
                <tr key={item.auditId}>
                  <td>{item.auditId}</td>
                  <td>{item.actorName}</td>
                  <td>{item.module}</td>
                  <td>{item.action}</td>
                  <td>{formatDate(item.timestamp)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
