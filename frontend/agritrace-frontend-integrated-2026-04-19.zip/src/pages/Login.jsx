import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import FoodSlider from "../components/FoodSlider";
import { useAuth } from "../context/AuthContext";
import { DEFAULT_USERS } from "../services/storageService";
import "../styles/Login.css";

const ROLES = ["Farmer", "Processor", "Distributor", "Retailer", "Admin"];

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, authError, loading, clearError } = useAuth();

  const [role, setRole] = useState("Farmer");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const redirectPath = location.state?.from?.pathname || "/dashboard";

  function validate() {
    const nextErrors = {};

    if (!email || !email.includes("@")) {
      nextErrors.email = "Please enter a valid email address.";
    }

    if (!password || password.length < 6) {
      nextErrors.password = "Password must be at least 6 characters.";
    }

    return nextErrors;
  }

  function handleLogin() {
    const nextErrors = validate();

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    clearError();

    login({ email, password, role })
      .then(() => {
        setSuccess(true);
        window.setTimeout(() => navigate(redirectPath), 1200);
      })
      .catch(() => {
        setSuccess(false);
      });
  }

  function handleKeyDown(event) {
    if (event.key === "Enter") {
      handleLogin();
    }
  }

  return (
    <div className="login-page">
      <FoodSlider />

      <div className="login-content">
        <div className="login-left">
          <div className="login-logo">
            <div className="login-logo-icon">🌱</div>
            <span className="login-logo-name">AgriTrace</span>
          </div>
          <h1 className="login-tagline">Farm-to-table traceability, simplified.</h1>
          <p className="login-subtext">
            Track every product from harvest to consumer with full transparency
            and accountability at every stage.
          </p>
          <ul className="login-features">
            <li><span className="feature-icon">📦</span> Register and track batches</li>
            <li><span className="feature-icon">🔄</span> Log supply chain movements</li>
            <li><span className="feature-icon">✅</span> Certify and verify produce</li>
            <li><span className="feature-icon">📊</span> Generate audit reports</li>
          </ul>

          <div className="demo-panel">
            <p className="demo-label">Quick demo access</p>
            <div className="demo-grid">
              {DEFAULT_USERS.map((account) => (
                <button
                  key={account.role}
                  type="button"
                  className="demo-chip"
                  onClick={() => {
                    setRole(account.role);
                    setEmail(account.email);
                    setPassword(account.password);
                    setErrors({});
                    clearError();
                  }}
                >
                  <strong>{account.role}</strong>
                  <span>{account.email}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="login-right">
          <div className="login-card">
            {success ? (
              <div className="login-success">
                <div className="success-icon">✅</div>
                <h2>Signed in successfully!</h2>
                <p>Redirecting to your dashboard...</p>
              </div>
            ) : (
              <>
                <h2 className="card-title">Welcome back</h2>
                <p className="card-sub">Sign in to your AgriTrace account</p>

                <p className="role-label">Sign in as</p>
                <div className="role-row">
                  {ROLES.map((entry) => (
                    <button
                      key={entry}
                      type="button"
                      className={`role-btn ${role === entry ? "active" : ""}`}
                      onClick={() => {
                        setRole(entry);
                        clearError();
                      }}
                    >
                      {entry}
                    </button>
                  ))}
                </div>

                <div className="form-field">
                  <label>Email address</label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => {
                      setEmail(event.target.value);
                      setErrors((current) => ({ ...current, email: "" }));
                    }}
                    onKeyDown={handleKeyDown}
                    className={errors.email ? "input-error" : ""}
                  />
                  {errors.email ? <span className="err-msg">{errors.email}</span> : null}
                </div>

                <div className="form-field">
                  <label>Password</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(event) => {
                      setPassword(event.target.value);
                      setErrors((current) => ({ ...current, password: "" }));
                    }}
                    onKeyDown={handleKeyDown}
                    className={errors.password ? "input-error" : ""}
                  />
                  {errors.password ? <span className="err-msg">{errors.password}</span> : null}
                </div>

                {authError ? <p className="auth-banner">{authError}</p> : null}

                <div className="forgot-row">
                  <a href="#">Forgot password?</a>
                </div>

                <button className="btn-primary" type="button" onClick={handleLogin} disabled={loading}>
                  {loading ? "Signing in..." : "Sign in →"}
                </button>

                <div className="divider">
                  <span />
                  <p>or</p>
                  <span />
                </div>

                <p className="bottom-link">
                  Don&apos;t have an account? <Link to="/register">Create one →</Link>
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
