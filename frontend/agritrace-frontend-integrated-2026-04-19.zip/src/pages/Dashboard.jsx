import { useAuth } from "../context/AuthContext";
import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Dashboard() {
  const { user } = useAuth();
  const { products, batches, logs, locations, notifications } = useAppData();

  const inTransit = batches.filter((item) => item.status === "In Transit").length;
  const delivered = batches.filter((item) => item.status === "Delivered").length;
  const liveOnline = locations.filter((item) => item.status === "Online").length;
  const recentLogs = [...logs].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 5);
  const alertItems = notifications.filter((item) => item.status === "Unread").slice(0, 4);

  return (
    <div className="content-stack">
      <section className="hero-panel">
        <div>
          <p className="eyebrow">Welcome back</p>
          <h2>{user?.name}</h2>
          <p className="hero-copy">
            Your integrated frontend now connects auth, batch tracking, live locations,
            and reports in one demo-ready workspace.
          </p>
        </div>
        <div className="hero-metrics">
          <div>
            <strong>{products.length}</strong>
            <span>Registered products</span>
          </div>
          <div>
            <strong>{batches.length}</strong>
            <span>Active batches</span>
          </div>
          <div>
            <strong>{logs.length}</strong>
            <span>Trace logs</span>
          </div>
        </div>
      </section>

      <section className="stats-grid">
        <article className="stat-card">
          <p>Total products</p>
          <h3>{products.length}</h3>
          <span>Registry is synced with seeded demo data.</span>
        </article>
        <article className="stat-card">
          <p>In transit</p>
          <h3>{inTransit}</h3>
          <span>Shipments currently moving between checkpoints.</span>
        </article>
        <article className="stat-card">
          <p>Delivered</p>
          <h3>{delivered}</h3>
          <span>Batches that completed the full chain.</span>
        </article>
        <article className="stat-card">
          <p>Live nodes online</p>
          <h3>{liveOnline}</h3>
          <span>Locations actively reporting to the dashboard.</span>
        </article>
      </section>

      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Recent movement</p>
              <h3>Supply chain timeline</h3>
            </div>
          </div>

          <div className="timeline-list">
            {recentLogs.map((item) => (
              <div className="timeline-item" key={item.logId}>
                <div className="timeline-dot" />
                <div>
                  <strong>{item.stage}</strong>
                  <p>
                    {item.batchId} at {item.locationName}
                  </p>
                </div>
                <time>{formatDate(item.timestamp)}</time>
              </div>
            ))}
          </div>
        </article>

        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Priority focus</p>
              <h3>Unread alerts</h3>
            </div>
          </div>

          <div className="stack-list">
            {alertItems.length ? (
              alertItems.map((item) => (
                <div className="soft-row" key={item.notificationId}>
                  <strong>{item.message}</strong>
                  <span>{formatDate(item.createdAt)}</span>
                </div>
              ))
            ) : (
              <div className="empty-state">
                <h4>No new alerts</h4>
                <p>Fresh notifications will appear here when new activity is logged.</p>
              </div>
            )}
          </div>
        </article>
      </section>

      <section className="three-column-grid">
        {[
          { label: "Harvested", value: logs.filter((item) => item.stage === "Harvested").length },
          { label: "Quality Check", value: logs.filter((item) => item.stage === "Quality Check").length },
          { label: "Delivered", value: logs.filter((item) => item.stage === "Delivered").length },
        ].map((item) => (
          <article className="mini-card" key={item.label}>
            <p>{item.label}</p>
            <strong>{item.value}</strong>
            <div className="mini-bar">
              <span style={{ width: `${Math.max(18, item.value * 18)}%` }} />
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
