import { useEffect, useState } from "react";
import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Locations() {
  const { locations, logs, createLocation, isActionLoading } = useAppData();
  const [pulse, setPulse] = useState(0);
  const [form, setForm] = useState({
    name: "",
    type: "Warehouse",
    city: "",
    state: "",
    status: "Online",
  });

  useEffect(() => {
    const timer = window.setInterval(() => {
      setPulse((current) => current + 1);
    }, 3200);

    return () => window.clearInterval(timer);
  }, []);

  function handleSubmit(event) {
    event.preventDefault();

    if (!form.name.trim() || !form.city.trim() || !form.state.trim()) {
      return;
    }

    createLocation(form).then(() => {
      setForm({
        name: "",
        type: "Warehouse",
        city: "",
        state: "",
        status: "Online",
      });
    }).catch(() => {});
  }

  const recentMovement = [...logs]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 5);

  return (
    <div className="content-stack">
      <section className="hero-panel">
        <div>
          <p className="eyebrow">Live tracking</p>
          <h2>Location network is active</h2>
          <p className="hero-copy">
            This page was built as the live locations view you requested, with simulated
            pulses, recent movement, and tracked network nodes.
          </p>
        </div>
        <div className="hero-metrics">
          <div>
            <strong>{locations.length}</strong>
            <span>Tracked locations</span>
          </div>
          <div>
            <strong>{locations.filter((item) => item.status === "Online").length}</strong>
            <span>Online nodes</span>
          </div>
          <div>
            <strong>{recentMovement.length}</strong>
            <span>Latest movement events</span>
          </div>
        </div>
      </section>

      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Network map</p>
              <h3>Live checkpoint overview</h3>
            </div>
          </div>

          <div className="map-card">
            <div className="map-grid-overlay" />
            {locations.map((item, index) => (
              <div
                key={item.locationId}
                className={`map-node ${pulse % locations.length === index ? "map-node-active" : ""}`}
                style={{ left: `${item.x}%`, top: `${item.y}%` }}
              >
                <span />
                <strong>{item.name}</strong>
                <small>{item.status}</small>
              </div>
            ))}
          </div>
        </article>

        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Recent movement</p>
              <h3>Last recorded trace updates</h3>
            </div>
          </div>
          <div className="timeline-list">
            {recentMovement.map((item) => (
              <div className="timeline-item" key={item.logId}>
                <div className="timeline-dot" />
                <div>
                  <strong>{item.locationName}</strong>
                  <p>
                    {item.stage} for {item.batchId}
                  </p>
                </div>
                <time>{formatDate(item.timestamp)}</time>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="two-column-grid">
        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Add location</p>
              <h3>Create a new live node</h3>
            </div>
          </div>

          <form className="form-stack" onSubmit={handleSubmit}>
            <div className="form-grid">
              <label className="form-span-2">
                Name
                <input
                  value={form.name}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, name: event.target.value }))
                  }
                  placeholder="South Market Receiving Dock"
                />
              </label>
              <label>
                Type
                <select
                  value={form.type}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, type: event.target.value }))
                  }
                >
                  <option>Farm</option>
                  <option>Warehouse</option>
                  <option>Processing</option>
                  <option>Transport</option>
                  <option>Retail</option>
                </select>
              </label>
              <label>
                Status
                <select
                  value={form.status}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, status: event.target.value }))
                  }
                >
                  <option>Online</option>
                  <option>In Transit</option>
                  <option>Receiving</option>
                  <option>Maintenance</option>
                </select>
              </label>
              <label>
                City
                <input
                  value={form.city}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, city: event.target.value }))
                  }
                  placeholder="Chennai"
                />
              </label>
              <label>
                State
                <input
                  value={form.state}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, state: event.target.value }))
                  }
                  placeholder="Tamil Nadu"
                />
              </label>
            </div>
            <button className="primary-action" type="submit" disabled={isActionLoading("createLocation")}>
              {isActionLoading("createLocation") ? "Adding..." : "Add live location"}
            </button>
          </form>
        </article>

        <article className="panel-card">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Tracked nodes</p>
              <h3>Location cards</h3>
            </div>
          </div>
          <div className="stack-list">
            {locations.map((item) => (
              <div className="location-row" key={item.locationId}>
                <div>
                  <strong>{item.name}</strong>
                  <p>
                    {item.type} · {item.city}, {item.state}
                  </p>
                </div>
                <div className="location-meta">
                  <span>{item.temperature}</span>
                  <strong>{item.lastPingMinutes} min ago</strong>
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}
