import { useAppData } from "../context/AppDataContext";

function formatDate(value) {
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Notifications() {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isActionLoading,
  } = useAppData();

  return (
    <div className="content-stack">
      <section className="panel-card">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Inbox</p>
            <h3>Activity notifications</h3>
          </div>
          {notifications.some((item) => item.status === "Unread") ? (
            <button
              className="secondary-action"
              type="button"
              onClick={() => markAllNotificationsAsRead()}
              disabled={isActionLoading("markAllNotificationsAsRead")}
            >
              {isActionLoading("markAllNotificationsAsRead") ? "Saving..." : "Mark all as read"}
            </button>
          ) : null}
        </div>

        {notifications.length ? (
          <div className="stack-list">
            {notifications.map((item) => (
              <div className="notification-row" key={item.notificationId}>
                <div>
                  <strong>{item.message}</strong>
                  <p>{formatDate(item.createdAt)}</p>
                </div>
                {item.status === "Unread" ? (
                  <button
                    className="secondary-action"
                    type="button"
                    onClick={() => markNotificationAsRead(item.notificationId)}
                    disabled={isActionLoading("markNotificationAsRead")}
                  >
                    {isActionLoading("markNotificationAsRead") ? "Saving..." : "Mark as read"}
                  </button>
                ) : (
                  <span className="status-chip neutral-chip">Read</span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h4>No notifications yet</h4>
            <p>Create products, batches, logs, or locations to generate new alerts.</p>
          </div>
        )}
      </section>
    </div>
  );
}
