const STORAGE_KEYS = {
  users: "agritrace_users",
  currentUser: "agritrace_current_user",
  products: "agritrace_products",
  batches: "agritrace_batches",
  logs: "agritrace_logs",
  locations: "agritrace_locations",
  notifications: "agritrace_notifications",
  audit: "agritrace_audit",
};

export const DEFAULT_USERS = [
  {
    userId: 1,
    name: "Riya Farmer",
    email: "farmer@agritrace.app",
    password: "Farmer@123",
    role: "Farmer",
    orgName: "Green Valley Farm",
    phone: "+91 98765 11111",
    region: "Karnataka",
  },
  {
    userId: 2,
    name: "Amit Processor",
    email: "processor@agritrace.app",
    password: "Processor@123",
    role: "Processor",
    orgName: "Harvest Foods",
    phone: "+91 98765 22222",
    region: "Maharashtra",
  },
  {
    userId: 3,
    name: "Neha Distributor",
    email: "distributor@agritrace.app",
    password: "Distributor@123",
    role: "Distributor",
    orgName: "FreshLink Logistics",
    phone: "+91 98765 33333",
    region: "Tamil Nadu",
  },
  {
    userId: 4,
    name: "Karan Retailer",
    email: "retailer@agritrace.app",
    password: "Retailer@123",
    role: "Retailer",
    orgName: "Farm Basket Store",
    phone: "+91 98765 44444",
    region: "Kerala",
  },
  {
    userId: 5,
    name: "Admin User",
    email: "admin@agritrace.app",
    password: "Admin@123",
    role: "Admin",
    orgName: "AgriTrace HQ",
    phone: "+91 98765 55555",
    region: "Karnataka",
  },
];

const DEFAULT_PRODUCTS = [
  {
    productId: "PRD-1001",
    productName: "Organic Tomatoes",
    category: "Vegetables",
    origin: "Kolar, Karnataka",
    ownerName: "Riya Farmer",
    notes: "Greenhouse harvested lot",
    createdAt: "2026-04-10T07:30:00.000Z",
  },
  {
    productId: "PRD-1002",
    productName: "Alphonso Mangoes",
    category: "Fruits",
    origin: "Ratnagiri, Maharashtra",
    ownerName: "Riya Farmer",
    notes: "Premium export grade",
    createdAt: "2026-04-11T06:45:00.000Z",
  },
  {
    productId: "PRD-1003",
    productName: "Cold Pressed Milk",
    category: "Dairy",
    origin: "Mysuru, Karnataka",
    ownerName: "Amit Processor",
    notes: "Processed and packed same day",
    createdAt: "2026-04-12T09:15:00.000Z",
  },
];

const DEFAULT_BATCHES = [
  {
    batchId: "BAT-7001",
    productId: "PRD-1001",
    productName: "Organic Tomatoes",
    quantity: "1200 kg",
    harvestDate: "2026-04-12",
    eta: "2026-04-20",
    status: "In Transit",
    qualityScore: 96,
    certificateId: "CERT-2026-011",
  },
  {
    batchId: "BAT-7002",
    productId: "PRD-1002",
    productName: "Alphonso Mangoes",
    quantity: "900 kg",
    harvestDate: "2026-04-13",
    eta: "2026-04-21",
    status: "Ready for Dispatch",
    qualityScore: 93,
    certificateId: "CERT-2026-014",
  },
  {
    batchId: "BAT-7003",
    productId: "PRD-1003",
    productName: "Cold Pressed Milk",
    quantity: "450 crates",
    harvestDate: "2026-04-14",
    eta: "2026-04-19",
    status: "Delivered",
    qualityScore: 98,
    certificateId: "CERT-2026-018",
  },
];

const DEFAULT_LOCATIONS = [
  {
    locationId: "LOC-01",
    name: "Green Valley Farm",
    type: "Farm",
    city: "Kolar",
    state: "Karnataka",
    status: "Online",
    x: 14,
    y: 66,
    temperature: "19 C",
    lastPingMinutes: 2,
  },
  {
    locationId: "LOC-02",
    name: "Harvest Foods Hub",
    type: "Processing",
    city: "Pune",
    state: "Maharashtra",
    status: "Online",
    x: 32,
    y: 48,
    temperature: "17 C",
    lastPingMinutes: 4,
  },
  {
    locationId: "LOC-03",
    name: "FreshLink Transit Yard",
    type: "Transport",
    city: "Salem",
    state: "Tamil Nadu",
    status: "In Transit",
    x: 49,
    y: 58,
    temperature: "22 C",
    lastPingMinutes: 1,
  },
  {
    locationId: "LOC-04",
    name: "Metro Retail Dock",
    type: "Retail",
    city: "Kochi",
    state: "Kerala",
    status: "Receiving",
    x: 72,
    y: 70,
    temperature: "18 C",
    lastPingMinutes: 6,
  },
  {
    locationId: "LOC-05",
    name: "Northern Cold Store",
    type: "Warehouse",
    city: "Ludhiana",
    state: "Punjab",
    status: "Online",
    x: 43,
    y: 18,
    temperature: "12 C",
    lastPingMinutes: 5,
  },
];

const DEFAULT_LOGS = [
  {
    logId: "LOG-9001",
    batchId: "BAT-7001",
    stage: "Harvested",
    actorName: "Riya Farmer",
    locationId: "LOC-01",
    locationName: "Green Valley Farm",
    status: "Completed",
    timestamp: "2026-04-12T05:30:00.000Z",
  },
  {
    logId: "LOG-9002",
    batchId: "BAT-7001",
    stage: "Quality Check",
    actorName: "Amit Processor",
    locationId: "LOC-02",
    locationName: "Harvest Foods Hub",
    status: "Completed",
    timestamp: "2026-04-12T14:10:00.000Z",
  },
  {
    logId: "LOG-9003",
    batchId: "BAT-7001",
    stage: "Dispatched",
    actorName: "Neha Distributor",
    locationId: "LOC-03",
    locationName: "FreshLink Transit Yard",
    status: "Completed",
    timestamp: "2026-04-13T08:40:00.000Z",
  },
  {
    logId: "LOG-9004",
    batchId: "BAT-7002",
    stage: "Harvested",
    actorName: "Riya Farmer",
    locationId: "LOC-01",
    locationName: "Green Valley Farm",
    status: "Completed",
    timestamp: "2026-04-13T06:10:00.000Z",
  },
  {
    logId: "LOG-9005",
    batchId: "BAT-7003",
    stage: "Delivered",
    actorName: "Karan Retailer",
    locationId: "LOC-04",
    locationName: "Metro Retail Dock",
    status: "Completed",
    timestamp: "2026-04-15T11:00:00.000Z",
  },
];

const DEFAULT_NOTIFICATIONS = [
  {
    notificationId: "NTF-1",
    userId: 1,
    message: "Batch BAT-7002 is queued for dispatch approval.",
    status: "Unread",
    createdAt: "2026-04-17T05:20:00.000Z",
  },
  {
    notificationId: "NTF-2",
    userId: 2,
    message: "Quality check completed for Organic Tomatoes.",
    status: "Unread",
    createdAt: "2026-04-17T07:15:00.000Z",
  },
  {
    notificationId: "NTF-3",
    userId: 3,
    message: "FreshLink Transit Yard reported a live movement ping.",
    status: "Read",
    createdAt: "2026-04-17T09:45:00.000Z",
  },
  {
    notificationId: "NTF-4",
    userId: 5,
    message: "Audit coverage reached 98 percent this week.",
    status: "Unread",
    createdAt: "2026-04-18T04:05:00.000Z",
  },
];

const DEFAULT_AUDIT = [
  {
    auditId: "AUD-1",
    actorName: "Admin User",
    action: "Reviewed weekly compliance snapshot",
    module: "Reports",
    timestamp: "2026-04-18T06:00:00.000Z",
  },
  {
    auditId: "AUD-2",
    actorName: "Amit Processor",
    action: "Validated batch BAT-7001 quality score",
    module: "Batches",
    timestamp: "2026-04-17T14:20:00.000Z",
  },
  {
    auditId: "AUD-3",
    actorName: "Neha Distributor",
    action: "Updated live transport checkpoint",
    module: "Locations",
    timestamp: "2026-04-17T11:50:00.000Z",
  },
];

const DEFAULT_DATA = {
  users: DEFAULT_USERS,
  products: DEFAULT_PRODUCTS,
  batches: DEFAULT_BATCHES,
  logs: DEFAULT_LOGS,
  locations: DEFAULT_LOCATIONS,
  notifications: DEFAULT_NOTIFICATIONS,
  audit: DEFAULT_AUDIT,
};

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function seedStorage() {
  Object.entries(DEFAULT_DATA).forEach(([name, value]) => {
    const key = STORAGE_KEYS[name];
    if (!localStorage.getItem(key)) {
      writeJson(key, value);
    }
  });
}

export function getCollection(name) {
  seedStorage();
  return readJson(STORAGE_KEYS[name], DEFAULT_DATA[name] || []);
}

export function saveCollection(name, items) {
  writeJson(STORAGE_KEYS[name], items);
}

export function getCurrentUserFromStorage() {
  return readJson(STORAGE_KEYS.currentUser, null);
}

export function saveCurrentUser(user) {
  writeJson(STORAGE_KEYS.currentUser, user);
}

export function clearCurrentUser() {
  localStorage.removeItem(STORAGE_KEYS.currentUser);
}

export function createReadableId(prefix) {
  const random = Math.floor(Math.random() * 9000) + 1000;
  return `${prefix}-${random}`;
}
