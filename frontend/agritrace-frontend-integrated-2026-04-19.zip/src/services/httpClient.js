import axios from "axios";
import { clearToken, getStoredToken } from "./tokenService";
import { clearCurrentUser } from "./storageService";

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").trim();

export const apiClient = axios.create({
  baseURL: API_BASE_URL || "/api",
  timeout: 10000,
});

apiClient.interceptors.request.use((config) => {
  const token = getStoredToken();

  if (token) {
    config.headers = {
      ...config.headers,
      Authorization: `Bearer ${token}`,
    };
  }

  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      clearToken();
      clearCurrentUser();
    }

    return Promise.reject(error);
  }
);

export function isRemoteApiEnabled() {
  return Boolean(API_BASE_URL);
}

