import { apiClient, isRemoteApiEnabled } from "./httpClient";
import { createReadableId, getCollection, saveCollection, seedStorage } from "./storageService";

function sortByCreatedAtDesc(items) {
  return [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export async function listProducts() {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.get("/products");
    return response.data || [];
  }

  seedStorage();
  return sortByCreatedAtDesc(getCollection("products"));
}

export async function createProduct(payload, user) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/products", payload);
    return response.data;
  }

  const nextProduct = {
    productId: createReadableId("PRD"),
    productName: payload.productName,
    category: payload.category,
    origin: payload.origin,
    ownerName: user?.name || "Demo User",
    notes: payload.notes,
    createdAt: new Date().toISOString(),
  };

  const current = getCollection("products");
  saveCollection("products", [nextProduct, ...current]);
  return nextProduct;
}

