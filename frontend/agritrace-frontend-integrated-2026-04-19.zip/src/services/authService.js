import { apiClient, isRemoteApiEnabled } from "./httpClient";
import {
  DEFAULT_USERS,
  clearCurrentUser,
  getCollection,
  getCurrentUserFromStorage,
  saveCollection,
  saveCurrentUser,
  seedStorage,
} from "./storageService";
import { clearToken, getStoredToken, saveToken } from "./tokenService";

function sanitizeUser(user) {
  if (!user) {
    return null;
  }

  const safeUser = { ...user };
  delete safeUser.password;
  return safeUser;
}

function createDemoToken(user) {
  return `demo-jwt-${user.userId}-${Date.now()}`;
}

function getErrorMessage(error, fallback) {
  return error?.response?.data?.message || error?.message || fallback;
}

export async function login(credentials) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/auth/login", credentials);
    const payload = response.data || {};
    const user = sanitizeUser(payload.user);
    const token = payload.token;

    saveCurrentUser(user);
    saveToken(token);

    return { user, token };
  }

  seedStorage();

  const users = getCollection("users");
  const foundUser = users.find(
    (item) =>
      item.email.toLowerCase() === credentials.email.toLowerCase() &&
      item.password === credentials.password &&
      item.role === credentials.role
  );

  if (!foundUser) {
    throw new Error("Invalid email, password, or role.");
  }

  const user = sanitizeUser(foundUser);
  const token = createDemoToken(foundUser);

  saveCurrentUser(user);
  saveToken(token);

  return { user, token };
}

export async function register(payload) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/auth/register", payload);
    const result = response.data || {};
    const user = sanitizeUser(result.user);
    const token = result.token;

    saveCurrentUser(user);
    saveToken(token);

    return { user, token };
  }

  seedStorage();

  const users = getCollection("users");
  const exists = users.some((item) => item.email.toLowerCase() === payload.email.toLowerCase());

  if (exists) {
    throw new Error("An account with this email already exists.");
  }

  const nextUser = {
    userId: users.length ? Math.max(...users.map((item) => item.userId)) + 1 : DEFAULT_USERS.length + 1,
    name: `${payload.firstName} ${payload.lastName}`.trim(),
    email: payload.email,
    password: payload.password,
    role: payload.role,
    orgName: payload.orgName,
    phone: payload.phone,
    region: payload.region,
  };

  saveCollection("users", [...users, nextUser]);

  const user = sanitizeUser(nextUser);
  const token = createDemoToken(nextUser);

  saveCurrentUser(user);
  saveToken(token);

  return { user, token };
}

export async function logout() {
  if (isRemoteApiEnabled()) {
    try {
      await apiClient.post("/auth/logout");
    } catch {
      // Ignore logout failures so local state is always cleared.
    }
  }

  clearCurrentUser();
  clearToken();
}

export function getSession() {
  const user = getCurrentUserFromStorage();
  const token = getStoredToken();

  if (!user || !token) {
    return { user: null, token: null };
  }

  return { user, token };
}

export function getFriendlyAuthError(error, fallback = "Unable to complete authentication.") {
  return getErrorMessage(error, fallback);
}

