import { apiClient, isRemoteApiEnabled } from "./httpClient";
import { createReadableId, getCollection, saveCollection, seedStorage } from "./storageService";

function sortByHarvestDateDesc(items) {
  return [...items].sort((a, b) => new Date(b.harvestDate) - new Date(a.harvestDate));
}

export async function listBatches() {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.get("/batches");
    return response.data || [];
  }

  seedStorage();
  return sortByHarvestDateDesc(getCollection("batches"));
}

export async function createBatch(payload, products) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/batches", payload);
    return response.data;
  }

  const selectedProduct = products.find((item) => item.productId === payload.productId);
  const nextBatch = {
    batchId: createReadableId("BAT"),
    productId: payload.productId,
    productName: selectedProduct?.productName || "Unknown Product",
    quantity: payload.quantity,
    harvestDate: payload.harvestDate,
    eta: payload.eta,
    status: payload.status,
    qualityScore: payload.qualityScore,
    certificateId: payload.certificateId || createReadableId("CERT"),
  };

  const current = getCollection("batches");
  saveCollection("batches", [nextBatch, ...current]);
  return nextBatch;
}

export async function updateBatchStatus(batchId, status) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.patch(`/batches/${batchId}`, { status });
    return response.data;
  }

  const current = getCollection("batches");
  const updated = current.map((item) => (item.batchId === batchId ? { ...item, status } : item));
  saveCollection("batches", updated);
  return updated.find((item) => item.batchId === batchId) || null;
}

