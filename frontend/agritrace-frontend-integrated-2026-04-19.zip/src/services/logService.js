import { apiClient, isRemoteApiEnabled } from "./httpClient";
import { createReadableId, getCollection, saveCollection, seedStorage } from "./storageService";

function sortByTimestampDesc(items) {
  return [...items].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

export async function listLogs() {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.get("/logs");
    return response.data || [];
  }

  seedStorage();
  return sortByTimestampDesc(getCollection("logs"));
}

export async function createLog(payload, context) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/logs", payload);
    return response.data;
  }

  const { batches, locations, user } = context;
  const selectedLocation = locations.find((item) => item.locationId === payload.locationId);
  const selectedBatch = batches.find((item) => item.batchId === payload.batchId);

  const nextLog = {
    logId: createReadableId("LOG"),
    batchId: payload.batchId,
    stage: payload.stage,
    actorName: user?.name || "Demo User",
    locationId: payload.locationId,
    locationName: selectedLocation?.name || "Unknown location",
    status: payload.status,
    timestamp: new Date().toISOString(),
    productName: selectedBatch?.productName || "",
  };

  const current = getCollection("logs");
  saveCollection("logs", [nextLog, ...current]);
  return nextLog;
}

