import { apiClient, isRemoteApiEnabled } from "./httpClient";
import { createReadableId, getCollection, saveCollection, seedStorage } from "./storageService";

function sortByCreatedAtDesc(items) {
  return [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export async function listNotifications(userId) {
  if (!userId) {
    return [];
  }

  if (isRemoteApiEnabled()) {
    const response = await apiClient.get("/notifications", {
      params: { userId },
    });
    return response.data || [];
  }

  seedStorage();
  return sortByCreatedAtDesc(getCollection("notifications").filter((item) => item.userId === userId));
}

export async function createNotification(message, userId) {
  if (!userId) {
    return null;
  }

  if (isRemoteApiEnabled()) {
    const response = await apiClient.post("/notifications", { message, userId });
    return response.data;
  }

  const nextNotification = {
    notificationId: createReadableId("NTF"),
    userId,
    message,
    status: "Unread",
    createdAt: new Date().toISOString(),
  };

  const current = getCollection("notifications");
  saveCollection("notifications", [nextNotification, ...current]);
  return nextNotification;
}

export async function markNotificationAsRead(notificationId) {
  if (isRemoteApiEnabled()) {
    const response = await apiClient.patch(`/notifications/${notificationId}`, {
      status: "Read",
    });
    return response.data;
  }

  const current = getCollection("notifications");
  const updated = current.map((item) =>
    item.notificationId === notificationId ? { ...item, status: "Read" } : item
  );
  saveCollection("notifications", updated);
  return updated.find((item) => item.notificationId === notificationId) || null;
}

export async function markAllNotificationsAsRead(userId) {
  if (!userId) {
    return [];
  }

  if (isRemoteApiEnabled()) {
    const response = await apiClient.patch("/notifications/mark-all-read", { userId });
    return response.data || [];
  }

  const current = getCollection("notifications");
  const updated = current.map((item) =>
    item.userId === userId ? { ...item, status: "Read" } : item
  );
  saveCollection("notifications", updated);
  return updated.filter((item) => item.userId === userId);
}

