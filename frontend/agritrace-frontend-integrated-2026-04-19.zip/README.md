# AgriTrace Frontend

Integrated React frontend for AgriTrace with:

- login and registration flows
- dashboard overview
- products, batches, and logs modules
- live locations page
- reports page
- notifications
- admin audit trail

## Run

```bash
npm install
npm run dev
```

## Demo Accounts

- Farmer: `farmer@agritrace.app` / `Farmer@123`
- Processor: `processor@agritrace.app` / `Processor@123`
- Distributor: `distributor@agritrace.app` / `Distributor@123`
- Retailer: `retailer@agritrace.app` / `Retailer@123`
- Admin: `admin@agritrace.app` / `Admin@123`

## Notes

- Data is seeded locally in `localStorage`.
- New products, batches, logs, locations, notifications, and users persist in the browser.
